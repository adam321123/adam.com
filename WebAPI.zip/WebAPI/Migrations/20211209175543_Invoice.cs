﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebAPI.Migrations
{
    public partial class Invoice : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    custId = table.Column<string>(type: "varchar(200)", nullable: false),
                    name = table.Column<string>(type: "varchar(200)", nullable: true),
                    address = table.Column<string>(type: "varchar(200)", nullable: true),
                    city = table.Column<string>(type: "varchar(200)", nullable: true),
                    phone = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.custId);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    prodId = table.Column<string>(type: "varchar(200)", nullable: false),
                    supplyId = table.Column<string>(type: "varchar(200)", nullable: true),
                    category = table.Column<string>(type: "varchar(200)", nullable: true),
                    pubprice = table.Column<string>(type: "varchar(200)", nullable: true),
                    stdcost = table.Column<string>(type: "varchar(200)", nullable: true),
                    sellprice = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.prodId);
                });

            migrationBuilder.CreateTable(
                name: "Invoices",
                columns: table => new
                {
                    invId = table.Column<string>(type: "varchar(200)", nullable: false),
                    date = table.Column<DateTime>(type: "date", nullable: false),
                    custId = table.Column<string>(type: "varchar(200)", nullable: true),
                    prodId = table.Column<string>(type: "varchar(200)", nullable: true),
                    qtysold = table.Column<string>(type: "varchar(200)", nullable: true),
                    sellprice = table.Column<string>(type: "varchar(50)", nullable: true),
                    pubprice = table.Column<string>(type: "varchar(50)", nullable: true),
                    stdcost = table.Column<string>(type: "varchar(100)", nullable: true),
                    category = table.Column<string>(type: "varchar(200)", nullable: true),
                    totalsold = table.Column<string>(type: "varchar(200)", nullable: true),
                    lastcost = table.Column<string>(type: "varchar(100)", nullable: true),
                    stdcosttot = table.Column<string>(type: "varchar(100)", nullable: true),
                    lastcosttot = table.Column<string>(type: "varchar(100)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Invoices", x => x.invId);
                    table.ForeignKey(
                        name: "FK_Invoices_Customers_custId",
                        column: x => x.custId,
                        principalTable: "Customers",
                        principalColumn: "custId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_custId",
                table: "Invoices",
                column: "custId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Invoices");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Customers");
        }
    }
}
