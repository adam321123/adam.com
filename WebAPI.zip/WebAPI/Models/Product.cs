﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebAPI.Models
{
    public class Product
    {
        [Key]
        [Column(TypeName = "varchar(200)")]
        public string prodId { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string supplyId { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string category { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string pubprice { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string stdcost { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string sellprice { get; set; }
    }
}
