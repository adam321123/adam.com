﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebAPI.Models
{
    public class Customer
    {
            [Key]
            [Column(TypeName = "varchar(200)")]
            public string custId { get; set; }

            [Column(TypeName = "varchar(200)")]
            public string name { get; set; }

            [Column(TypeName = "varchar(200)")]
            public string address { get; set; }

            [Column(TypeName = "varchar(200)")]
            public string city { get; set; }

            [Column(TypeName = "varchar(200)")]
            public string phone { get; set; }

            [ForeignKey("custId")]
            public ICollection<Invoice> Invoices { get; set; }
    }
}
