﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebAPI.Models
{
    public class Invoice
    {
        [Key]
        [Column(TypeName = "varchar(200)")]
        public string invId { get; set; }

        [Column(TypeName = "date")]
        public DateTime date { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string custId { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string prodId { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string qtysold { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string sellprice { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string pubprice { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string stdcost { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string category { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string totalsold { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string lastcost { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string stdcosttot { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string lastcosttot { get; set; }
    }
}
